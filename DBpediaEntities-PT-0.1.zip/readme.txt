*** DBpediaEntities-PT-0.1.zip ***

The resource DBpediaEntities-PT-0.1.zip contains three lists built from DBPedia version 3.8, each refering to a specific type of entity in the Portuguese version of Wikipedia (i.e., entities of the type Person, Location and Organization -- incluir mesmo os nomes das categorias na DBPedia).

Besides these three lists, we also included a file named photos.txt containing associations between Wikipedia URLs for the entities in the three lists above, and the corresponding photos in the Portuguese Wikipedia.
